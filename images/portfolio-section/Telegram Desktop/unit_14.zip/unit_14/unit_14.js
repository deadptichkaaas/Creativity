const param = {
	"url" : "https://api.openweathermap.org/data/2.5/",
	"appid" : "8688e803e2ce1790126464a71a571f43"
}
let cities =  {
   698740 : "Odessa",
   690548 : "Uzhgorod",
	706483 : "Kharkiv",
	707471 : "Ivano-Frankivsk",
	694423 : "Sevastopol",

}

function getWeather() {
	let cityId = document.querySelector('#city');
	// let cityId = document.getElementById("city");

	for (let key in cities) {
	  const option = document.createElement("option");
	  option.value = key;
	  option.textContent = cities[key];
	  cityId.add(option);
	}
	console.log(cityId);
	
	
	fetch(`${param.url}weather?id=${cityId}&units=metric&APPID=${param.appid}`)
	.then(weather => {
			return weather.json();
		}).then(showWeather);
}
function showWeather(data) {
	console.log(data);
	// for(let k in data) {
	// 	for( let i in data[k]) {
	// 		console.log(data[k][i]['description']);
	// 		if(data[k][i]['main'] == 'Clouds')
	// 		document.querySelector('.icon').innerHTML = '&#9729';
			
	// 	}		
	// 			}
			document.querySelector('.location').innerHTML = data.name;
			document.querySelector('.temp').innerHTML = Math.round(data.main.temp) + '&#176';
			document.querySelector('.description').innerHTML = data.weather[0]['description'];
			 document.querySelector('.icon').innerHTML = '&#9729';

		}

	// здесь вы выводите на страницу

getWeather(); 
document.querySelector('#city').onchange = getWeather;