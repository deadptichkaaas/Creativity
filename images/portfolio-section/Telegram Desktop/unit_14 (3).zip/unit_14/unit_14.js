// 716212c3798d8cb9d24d690854a3c0d4

// Коды городов!

const kzCitiesId = {

    'Almaty' : 1526384,
    'Astana' : 1526273,
    'Shymkent' : 1518980,
    'Aktobe' : 1526586,
    'Aktau' : 1526601,
    'Semey' : 1519422,
    'Turkistan' : 1524787,
    'Kyzylorda' : 1519922

}

// Перебор и добавление выбора в select

for (let key in kzCitiesId) {

    document.querySelector('.city-select').innerHTML += `<option value="${kzCitiesId[key]}">${key}</option>`;

}

// Получаем appid и url

const param = {
    'url' : 'https://api.openweathermap.org/data/2.5/',
    'appid' : '716212c3798d8cb9d24d690854a3c0d4'
}

// Получение погоды

function getWeather() {
    
    const cityId = document.querySelector('.city-select').value;

    console.log(cityId);

    fetch(`${param.url}weather?id=${cityId}&units=metric&APPID=${param.appid}`)
    .then(weather => {
        return weather.json();
    }).then(showWeather)

}

// Функция показа прогноза погоды - это функция callback

function showWeather(data) {

    console.log(data);



}

getWeather(); // При загрузке страницы сразу запускается ф-ция

document.querySelector('.city-select').onchange = getWeather(); // При смене городов функция запускается повторно
