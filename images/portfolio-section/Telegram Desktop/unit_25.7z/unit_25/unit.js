// Task 15
// При нажатии кнопки .b-15 срабатывает функция f15. Функция отсылает запрос на api.itgid.info со следующими параметрами:
// url: /api/25/sr/read
// method: POST
//
// если все сделано верно, то получите массив с описанием всех рас из игры КР.
// выведите в .out-15 изображения всех рас.
// в начале функции очистите .out-15
// выведите изображения рас в .out-15

function f15() {
	let out15 = document.querySelector('.out-15');
	let out = '';
	out15.innerHTML = '';
	xhr.open('POST', URL + url2);
	xhr.setRequestHeader('apikey', APIKEY);
	xhr.onload = () => {
		const inf = JSON.parse(xhr.response);
		console.log(inf);

		let img = document.createElement('img');
		for (let i = 0; i < inf.result.length; i++) {
			out += URL + inf.result[i]['image'] + ' ';
			img.src.push(out);
		}
		out15.prepend(img);
		console.log(out);
	};
	xhr.send();
}

document.querySelector('.b-15').onclick = f15;
