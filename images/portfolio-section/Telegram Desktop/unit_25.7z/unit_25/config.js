const URL = 'https://api.itgid.info';
const APIKEY = 'FG0CCZC4dWywhVa0';
const xhr = new XMLHttpRequest();

const url1 = '/api/25/random/random-string';
const url2 = '/api/25/sr/read';
const url3 = '/api/25/random/random-number';
const url4 = '/api/25/random/generate-password';
