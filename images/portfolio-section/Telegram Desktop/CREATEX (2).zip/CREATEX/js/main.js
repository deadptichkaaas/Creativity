$(function () {

	var mixer = mixitup('.directions__list');

	$('.directions__filter-btn').on('click', function () {
		$('.directions__filter-btn').removeClass('directions__filter-btn--active')
		$(this).addClass('directions__filter-btn--active')
	})

	$('.team__slider').slick({
		arrows: false,
		slidesToShow: 4,
		Infinite: true,
		draggable: false,
		responsive:
		[
			{
				breakpoint: 1100,
				settings:{
					slidesToShow: 3,
				} ,
			},
			{
				breakpoint: 750,
				settings:{
					slidesToShow: 2,
				} ,
			},
			{
				breakpoint: 500,
				settings:{
					slidesToShow: 1,
					draggable: true,
				} ,
			},
		]
	})
	$('.team__slider-prev').on('click', function (e) {
		e.preventDefault()
		$('.team__slider').slick('slickPrev')
	})
	$('.team__slider-next').on('click', function (e) {
		e.preventDefault()
		$('.team__slider').slick('slickNext')
	})

	$('.testimonials__slider').slick({
		arrows: false,
		dots: true,
		appendDots: $('.testimonials__dots'),
		responsive:
		[
			{
				breakpoint: 750,
				settings:{
					
				} ,
			},
			
		]
	})
	$('.testimonials__prev').on('click', function (e) {
		e.preventDefault()
		$('.testimonials__slider').slick('slickPrev')
	})
	$('.testimonials__next').on('click', function (e) {
		e.preventDefault()
		$('.testimonials__slider').slick('slickNext')
	})

	$('.program__acc-link').on('click', function (e) {
		e.preventDefault()
		$(this).toggleClass('program__acc-link--active')
		$(this).children('.program__acc-text').slideToggle()
	})

	$(".header__nav-list a, .header__top-btn, .footer__go-top").on("click", function (event) {
		//отменяем стандартную обработку нажатия по ссылке
		event.preventDefault()
		//забираем идентификатор бока с атрибута href
		var id = $(this).attr('href'),
			//узнаем высоту от начала страницы до блока на который ссылается якорь
			top = $(id).offset().top - 180
		//анимируем переход на расстояние - top за 1500 мс
		$('body,html').animate({ scrollTop: top }, 1200)
	});

  var headerTop = $('.header__top');
  var overlay = $('.overlay');

	setInterval(
		() => {
			$(window).on('scroll', function () {
				if ($(window).scrollTop() > 0 && $('.header__top').hasClass('header__top--open') === false) {
					$('.burger').addClass('burger--follow')
				} else {
					$('.burger').removeClass('burger--follow')
				}
			})
		}, 0);

  // Проверяем, есть ли сохраненное состояние в localStorage
  var isHeaderTopOpen = localStorage.getItem('isHeaderTopOpen') === 'true'

  // Если header__top был открыт, то закрываем его
  if (isHeaderTopOpen) {
    headerTop.removeClass('header__top--open')
    overlay.removeClass('overlay--show')
  }

  // Обрабатываем клик на элементах .burger и .overlay
  $('.burger, .overlay').on('click', function(e) {
    e.preventDefault();
    headerTop.toggleClass('header__top--open')
    overlay.toggleClass('overlay--show')

    // Сохраняем состояние header__top в localStorage
    var isHeaderTopOpen = headerTop.hasClass('header__top--open')
    localStorage.setItem('isHeaderTopOpen', isHeaderTopOpen)
  })


})
