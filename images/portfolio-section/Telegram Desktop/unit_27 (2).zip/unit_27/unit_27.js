
function f8(){
    out8.innerHTML = ""
    const requestHeaders = new Headers();
    requestHeaders.append("apikey", APIKEY)
    const promise_81 = new Promise((resolve) => {
        fetch(URL + '/api/27/sr/read/'+nameRace, {
            method: "GET",
            headers: requestHeaders,
        }).then(data => resolve(data.json()));
    
    });
    const promise_82 = new Promise((resolve) => {
        fetch(URL + '/api/27/sr/read?race=' +nameRace2, {
            method: "GET",
            headers: requestHeaders,
        }).then(data => resolve(data.json()));
    });
    Promise.all([promise_81, promise_82 ]).then( data => {
        console.log(data)
       
        let elem = document.createElement('img');
        let elem2 = document.createElement('img');
        out8.append(elem, elem2);
        elem.src = URL + data[0].result['image'] ;
        elem2.src = URL + data[1].result['image'] ;
         }
      
      )
}

document.querySelector('.b-8').onclick = f8;

