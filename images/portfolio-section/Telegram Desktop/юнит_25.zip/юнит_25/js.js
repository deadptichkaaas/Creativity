const xhttp = new XMLHttpRequest();
const url = "http://getpost.itgid.info/index2.php?";
const auth = "DXXXXXXXXXXX";
const name = 'Vasyl';
const num1 = [20, 10, 21];
const num2 = [3, 22, 10];
const year = 1985; 
const obj = {
    "action": 1,
    "action": 2,
    "action": 3,
    "action": 4,
    "action": 5,
    "action": 6,
    "action": 7,
    "action": 8,
    "action": 9
}

function getAction(obj) {
    let out = '';
for (let key in obj) {
    out += "&" + key + "=" + obj[key];
}
}

function t1() {
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.querySelector('.out-1').innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?auth=" + auth + getAction(obj));
    xhttp.send();
}